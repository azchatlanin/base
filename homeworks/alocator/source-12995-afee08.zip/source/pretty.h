#ifdef _MSC_VER 
    #define __PRETTY_FUNCTION__ __FUNCSIG__
#endif